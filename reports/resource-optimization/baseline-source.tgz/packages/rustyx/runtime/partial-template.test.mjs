import test from 'node:test';
import assert from 'node:assert/strict';
import { PartialTemplates, snapshotPartialTemplate } from './partial-template.mjs';
import { partialModel } from './app-partial-model.mjs';
const lazy = value => ({ $$typeof: Symbol.for('react.lazy'), _payload: {}, _init() { return value; } });
const rejection = () => { const p=Promise.reject(Object.assign(new Error('request'),{digest:'RUSTYX_PPR_DYNAMIC'}));p.catch(()=>{});return p; };

test('distinct static holes keep distinct replacement paths across visitors', async () => {
  const hole=()=>({$$typeof:Symbol.for('react.lazy'),_payload:{},_init(){throw Object.assign(new Error('request'),{digest:'RUSTYX_PPR_DYNAMIC'})}});
  const cache=new PartialTemplates(),consumer={moduleMap:{},serverModuleMap:{}};
  for(const name of ['Ada','Lin']){
    const snapshot=await cache.get('static',consumer,()=>({router:{},a:hole(),b:hole()}));
    const copy=partialModel(snapshot,{live:{router:{},a:name+'-a',b:name+'-b'}});
    assert.equal(copy.a._init(),name+'-a');assert.equal(copy.b._init(),name+'-b');
  }
});

test('static snapshots preserve promises, lazy nodes, sharing, collections and request-hole isolation', async () => {
  const shared={label:'built'};const model={router:{},promise:Promise.resolve(shared),lazy:lazy(shared),shared,map:new Map([['date',new Date(42)],['private',rejection()]]),set:new Set([shared])};
  model.self=model;
  const {model:snapshot}=await snapshotPartialTemplate(model);
  assert.equal(snapshot.self,snapshot);assert.equal(await snapshot.promise,snapshot.shared);
  assert.equal(snapshot.lazy._init(),snapshot.shared);assert.equal([...snapshot.set][0],snapshot.shared);
  assert.notEqual(snapshot.shared,shared);
  for(const name of ['Ada','Lin']){
    const copy=partialModel(snapshot,{live:{router:{},map:new Map([['private',Promise.resolve(name)]])}});
    assert.equal(await copy.map.get('private'),name);
    assert.equal(copy.map.get('date').getTime(),42);
    assert.equal((await copy.promise).label,'built');
    assert.equal(typeof copy.promise.then,'function');
  }
});

test('template cache uses exact static content AND manifests, with bounded retention', async () => {
  const cache=new PartialTemplates({maxEntries:2,maxBytes:1024});
  const a={moduleMap:{},serverModuleMap:{}},b={moduleMap:{},serverModuleMap:{}};let loads=0;
  const decode=()=>{loads++;return {router:{},tree:lazy('static')}};
  const first=await cache.get('first',a,decode);
  assert.equal(await cache.get('first',a,decode),first);assert.equal(loads,1);
  assert.notEqual(await cache.get('first',b,decode),first);assert.equal(loads,2);
  await cache.get('second',a,decode);await cache.get('third',a,decode);
  assert.equal(cache.entries.size,2);assert.ok(cache.bytes<=1024);
  assert.notEqual(await cache.get('first',a,decode),first);assert.equal(loads,5);
});

test('non-replayable values bypass snapshots without consuming streams or retaining decoder objects', async () => {
  for(const value of [new ReadableStream(),()=>{},new Uint8Array([1,2])]){
    const cache=new PartialTemplates(),consumer={moduleMap:{},serverModuleMap:{}};
    let loads=0;const decoded={value};const decode=()=>{loads++;return decoded};
    assert.equal(await cache.get('static',consumer,decode),decoded);
    assert.equal(await cache.get('static',consumer,decode),decoded);
    assert.equal(loads,2);assert.equal(cache.entries.get('static').model,undefined);
    if(value instanceof ReadableStream)assert.equal(value.locked,false);
  }
});

test('failed snapshots do not change ordinary error semantics and cancellation never poisons an entry', async () => {
  const cache=new PartialTemplates(),consumer={moduleMap:{},serverModuleMap:{}};
  const failed=Promise.reject(new Error('real render error'));failed.catch(()=>{});const model={failed};
  assert.equal(await cache.get('error',consumer,()=>model),model);
  const abort=new AbortController();
  const pending=cache.get('pending',consumer,()=>({pending:new Promise(()=>{})}),abort.signal);
  abort.abort(new Error('cancelled'));await assert.rejects(pending,/cancelled/);
  assert.ok(!cache.entries.has('pending'));
  const recovered=await cache.get('pending',consumer,()=>({value:'healthy'}));assert.equal(recovered.value,'healthy');
});
