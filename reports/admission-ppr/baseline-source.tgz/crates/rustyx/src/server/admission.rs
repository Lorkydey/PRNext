//! Bound waiting requests separately from requests with buffered bodies.
use std::{sync::Arc, time::Duration};
use tokio::sync::{OwnedSemaphorePermit, Semaphore};

pub(super) struct Admission {
    active: Arc<Semaphore>,
    waiting: Arc<Semaphore>,
    timeout: Duration,
    pub(super) bodies: crate::pool::BodyBudget,
}

#[derive(Debug)]
pub(super) enum AdmissionError {
    Full,
    Timeout,
}

impl Admission {
    pub(super) fn new(workers: usize) -> Self {
        Self::concurrent(workers, 1)
    }

    pub(super) fn concurrent(workers: usize, lanes: usize) -> Self {
        Self {
            // Waiters retain unread bodies; legacy stdio keeps four admissions.
            active: Arc::new(Semaphore::new(workers * lanes.max(4))),
            waiting: Arc::new(Semaphore::new(
                (workers * if lanes > 1 { 256 } else { 64 }).min(1024),
            )),
            timeout: Duration::from_secs(30),
            bodies: crate::pool::BodyBudget::default(),
        }
    }

    pub(super) async fn acquire(&self) -> Result<OwnedSemaphorePermit, AdmissionError> {
        if let Ok(permit) = self.active.clone().try_acquire_owned() {
            return Ok(permit);
        }
        // Waiters retain only the unconsumed HTTP request, not an 8 MiB body or
        // a base64 worker payload. Dropping this future releases its queue slot.
        let _waiting = self
            .waiting
            .clone()
            .try_acquire_owned()
            .map_err(|_| AdmissionError::Full)?;
        tokio::time::timeout(self.timeout, self.active.clone().acquire_owned())
            .await
            .map_err(|_| AdmissionError::Timeout)?
            .map_err(|_| AdmissionError::Full)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn waiting_is_bounded_and_cancellation_releases_capacity() {
        let admission = Arc::new(Admission {
            active: Arc::new(Semaphore::new(1)),
            waiting: Arc::new(Semaphore::new(1)),
            timeout: Duration::from_secs(1),
            bodies: crate::pool::BodyBudget::default(),
        });
        let running = admission.acquire().await.unwrap();
        let pending = tokio::spawn({
            let admission = admission.clone();
            async move { admission.acquire().await }
        });
        while admission.waiting.available_permits() != 0 {
            tokio::task::yield_now().await;
        }
        assert!(matches!(
            admission.acquire().await,
            Err(AdmissionError::Full)
        ));
        pending.abort();
        let _ = pending.await;
        assert_eq!(admission.waiting.available_permits(), 1);
        drop(running);
        assert!(admission.acquire().await.is_ok());
    }

    #[tokio::test]
    async fn waiters_resume_in_order_and_timeout_without_leaking_slots() {
        let admission = Arc::new(Admission {
            active: Arc::new(Semaphore::new(1)),
            waiting: Arc::new(Semaphore::new(2)),
            timeout: Duration::from_millis(100),
            bodies: crate::pool::BodyBudget::default(),
        });
        let running = admission.acquire().await.unwrap();
        let first = tokio::spawn({
            let admission = admission.clone();
            async move { admission.acquire().await }
        });
        while admission.waiting.available_permits() != 1 {
            tokio::task::yield_now().await;
        }
        drop(running);
        let first = first.await.unwrap().unwrap();
        assert!(matches!(
            admission.acquire().await,
            Err(AdmissionError::Timeout)
        ));
        assert_eq!(admission.waiting.available_permits(), 2);
        drop(first);
        assert!(admission.acquire().await.is_ok());
    }
}
