export const PHASE_EXPORT: 'phase-export';
export const PHASE_ANALYZE: 'phase-analyze';
export const PHASE_PRODUCTION_BUILD: 'phase-production-build';
export const PHASE_PRODUCTION_SERVER: 'phase-production-server';
export const PHASE_DEVELOPMENT_SERVER: 'phase-development-server';
export const PHASE_TEST: 'phase-test';
export const PHASE_INFO: 'phase-info';
